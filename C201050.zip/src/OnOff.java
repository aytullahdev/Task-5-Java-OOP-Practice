public interface OnOff {
    public void ComputerOn();
    public void ComputerOff();
}

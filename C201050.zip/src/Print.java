abstract class Print {

    abstract void print(String str);
}
